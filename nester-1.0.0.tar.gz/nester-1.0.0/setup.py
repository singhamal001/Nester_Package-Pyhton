from distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'amalrajsingh',
    author_email = 'singhamal001@gmail.com',
    url = 'https://github.com/singhamal001',
    description = 'A simple printer of nested lists',
)