"""This is a standard way to include
multiple line comment in
python"""

def print_lol (the_list):
    """So basically in here we enter  nested list,
    and to print all the elements individually we contact the
    same function in a loop until there's no more nested lists available."""
    for each_item in the_list:
        if isinstance(each_item, list):
            print_lol(each_item)
        else:
            print(each_item)
